#!/bin/bash
TOKEN="65897756"
USERNAME="test2"
RESIZE="" #width x height
/bin/cat list.txt | while read IMAGE
do
echo $IMAGE
/usr/bin/curl --form userfile=@$IMAGE --form token=$TOKEN --form username=$USERNAME --form resize=$RESIZE http://api.vn.visqua.com -o revo.$IMAGE
done
